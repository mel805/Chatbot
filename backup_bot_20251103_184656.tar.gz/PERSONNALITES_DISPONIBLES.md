# ?? Personnalit?s Disponibles (12 au total)

## ?? FEMMES (4 personnalit?s)

### 1. Femme Coquine
**Genre**: Femme  
**Style**: Directe, confiante, s?duisante  
**Id?al pour**: Conversations os?es, flirt explicite  
**Ton**: Assur?e et sans tabou

### 2. Femme Douce  
**Genre**: Femme  
**Style**: Romantique, tendre, passionn?e  
**Id?al pour**: Intimit? ?motionnelle et sensuelle  
**Ton**: Douce mais franche

### 3. Femme Dominante
**Genre**: Femme  
**Style**: Autoritaire, contr?le, directe  
**Id?al pour**: Dynamiques D/s, elle m?ne  
**Ton**: Assertive et commandante

### 4. Femme Soumise
**Genre**: Femme  
**Style**: Ob?issante, d?sireuse de plaire  
**Id?al pour**: Dynamiques D/s, elle suit  
**Ton**: Respectueuse et empress?e

---

## ?? HOMMES (4 personnalit?s)

### 5. Homme S?ducteur
**Genre**: Homme  
**Style**: Charmant, confiant, direct  
**Id?al pour**: S?duction, flirt assur?  
**Ton**: Confiant et s?duisant

### 6. Homme Dominant
**Genre**: Homme  
**Style**: Dominant, s?r de lui, autoritaire  
**Id?al pour**: Dynamiques D/s, il m?ne  
**Ton**: Assertif et contr?lant

### 7. Homme Doux
**Genre**: Homme  
**Style**: Tendre, attentionn?, romantique  
**Id?al pour**: Romance et passion  
**Ton**: Sensible et sinc?re

### 8. Homme Soumis
**Genre**: Homme  
**Style**: Ob?issant, d?sireux de satisfaire  
**Id?al pour**: Dynamiques D/s, il suit  
**Ton**: D?f?rent et enthousiaste

---

## ?????? TRANS / NON-BINAIRE (2 personnalit?s)

### 9. Trans Confiant
**Genre**: Trans  
**Style**: Confiant, authentique, direct  
**Id?al pour**: Exp?rience trans authentique  
**Ton**: Ouvert et assum?

### 10. Non-Binaire Joueur
**Genre**: Non-binaire  
**Style**: Fun, geek, d?contract?  
**Id?al pour**: M?lange humour et sensualit?  
**Ton**: Cool et ouvert

---

## ? NEUTRES (2 personnalit?s)

### 11. Amical
**Genre**: Neutre  
**Style**: Sympathique, ouvert d'esprit  
**Id?al pour**: Conversations vari?es sans jugement  
**Ton**: Naturel et franc

### 12. Intellectuel
**Genre**: Neutre  
**Style**: Cultiv?, articul?, ?loquent  
**Id?al pour**: Discussions profondes et raffin?es  
**Ton**: Sophistiqu? mais sans censure

---

## ?? Comment Changer de Personnalit?

### Sur Discord:

1. **Arr?tez le bot** (si actif):
   ```
   /stop
   ```

2. **Red?marrez avec nouveau choix**:
   ```
   /start
   ```

3. **S?lectionnez dans le menu** d?roulant

OU directement sans red?marrer:
```
/personality
```
*[S?lectionnez la nouvelle personnalit? dans le menu]*

---

## ?? Recommandations par Usage

### Pour Contenu NSFW Explicite:
- **Femme Coquine** ??
- **Homme S?ducteur** ??
- **Femme/Homme Dominant** ??

### Pour Romance + Sensualit?:
- **Femme/Homme Doux** ??
- **Femme Douce** ??

### Pour Dynamiques Dominant/Soumis:
- **Dominants**: Femme Dominante, Homme Dominant ??
- **Soumis**: Femme Soumise, Homme Soumis ??

### Pour Diversit? & Inclusion:
- **Trans Confiant** ??????
- **Non-Binaire Joueur** ??

### Pour Conversations Vari?es:
- **Amical** (polyvalent)
- **Intellectuel** (sophistiqu?)

---

## ?? Astuces d'Utilisation

### 1. Testez Plusieurs Personnalit?s
Chaque personnalit? r?agit diff?remment au m?me message. Exp?rimentez!

### 2. Soyez Explicite
Les nouvelles personnalit?s sont configur?es pour **ne pas refuser** le contenu adulte. Plus vous ?tes direct, plus elles le seront.

### 3. Le Contexte Compte
Les personnalit?s se souviennent des 20 derniers messages. Construisez une conversation progressive.

### 4. Variez les Sc?narios
- Femme Coquine pour du direct
- Homme Doux pour du romantique
- Dominant/Soumis pour des jeux de r?le

---

## ?? Nouveaut?s vs Anciennes Personnalit?s

### Avant (8 personnalit?s neutres):
- Amical, S?ducteur, Coquin, Romantique
- Dominant, Soumis, Joueur, Intellectuel
- ? Pas de genre d?fini
- ? Prompts parfois censur?s

### Maintenant (12 personnalit?s genr?es):
- **4 Femmes** avec personnalit?s vari?es
- **4 Hommes** avec personnalit?s vari?es  
- **2 Trans/Non-binaire** inclusifs
- **2 Neutres** polyvalents
- ? Genres clairs et assum?s
- ? Prompts anti-censure optimis?s
- ? Plus de choix et diversit?

---

## ?? S?curit? & Confidentialit?

- ? Toutes les conversations sont **priv?es**
- ? L'historique est limit? ? **20 messages par canal**
- ? Commande `/reset` efface l'historique
- ? Le bot ne garde **aucun log permanent** des conversations

---

## ?? Personnalisation Future

**Prochaines mises ? jour possibles:**
- Plus de personnalit?s par genre
- Variantes d'?ge (jeune adulte, mature)
- Accents/origines culturelles
- Professions sp?cifiques (infirmi?re, prof, etc.)

**Suggestions bienvenues!** ??

---

? **12 personnalit?s uniques pour tous les go?ts!**
